import { Injectable, Output, EventEmitter } from '@angular/core';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Doctor } from './doctor';

@Injectable({
  providedIn: 'root'
})

export class ApiService {
  redirectUrl: String = "";
  baseUrl: string = "http://localhost/medicale/doctor";
  @Output() getLoggedInName: EventEmitter<any> = new EventEmitter();
  constructor(private httpClient: HttpClient) { }
  public doctorlogin(Username: String, password: String) {
    alert(Username)
    return this.httpClient.post<any>(this.baseUrl + '/login.php', { Username, password })
      .pipe(map(Doctor => {

        this.getLoggedInName.emit(true);
        return Doctor;
      }));
  }
}
