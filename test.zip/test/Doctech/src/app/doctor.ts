import { Time } from '@angular/common';

export class Doctor {
  public idDoctor: number;
  public Username: String;
  public password: String;
  public TimeB: Time;
  public TimeC: Time;
  public User_idUser;

  constructor(idDoctor: number, Username: String, password: String, TimeB: Time, TimeC: Time, User_idUser: number) {
    this.idDoctor = idDoctor;
    this.Username = Username;
    this.password = password;
    this.TimeB = TimeB;
    this.TimeC = TimeC;
    this.User_idUser = User_idUser;
  }
}
